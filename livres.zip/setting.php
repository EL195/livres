<?php
error_reporting(0);
$set=mysqli_connect("localhost","root","","livre");

?>